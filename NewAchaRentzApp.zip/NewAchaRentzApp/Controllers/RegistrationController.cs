﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebPagesMvc.Data;

using WebPagesMvc.Models;

namespace WebPagesMvc.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly AppDbContext _context;
        public int tempData;
        public RegistrationController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register([Bind("UserName, Password, AgreedToTerms")] User registrationModel)
        {
            _context.Users.Add(registrationModel);
            await _context.SaveChangesAsync();
            return RedirectToAction("ExtraRegistrationDetailsPage", "Main");

        }

        [HttpGet]

        public IActionResult ExtraDetails()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ExtraDetails([Bind("FirstName, LastName, PhoneNumber, Email, AlternatePhoneNumber, Address, AadharNumber")] User userModel)
        { 
            _context.Users.Add(userModel);
            await _context.SaveChangesAsync();
            return RedirectToAction("HomePage", "Main");

        }

    }
}

