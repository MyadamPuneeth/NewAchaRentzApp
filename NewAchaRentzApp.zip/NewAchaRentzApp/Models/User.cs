﻿using System.ComponentModel.DataAnnotations;

namespace WebPagesMvc.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required, MaxLength(100)]
        public string UserName { get; set; }

        [Required, MaxLength(100)]
        public string Password { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Phone]
        public long? PhoneNumber { get; set; }

        [Phone]
        public long? AlternatePhoneNumber { get; set; }

        [MaxLength(255)]
        public string Address { get; set; }

        [Required, MaxLength(50)]
        public string FirstName { get; set; }

        [Required, MaxLength(50)]
        public string LastName { get; set; }

        public bool AgreedToTerms { get; set; }

        public long? AadharNumber { get; set; }
    }
}
